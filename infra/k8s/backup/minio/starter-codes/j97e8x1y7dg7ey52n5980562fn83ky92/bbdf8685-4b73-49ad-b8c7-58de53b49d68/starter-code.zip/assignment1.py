# Assignment 1 - Three Consecutive Odd

def three_consecutive_odd(lst):
    """
    Given a list of integers, return True if there are three consecutive odd numbers in the list. Otherwise, return False.

    Example 1:
    Input: arr = [2,6,4,1]
    Output: false
    Explanation: There are no three consecutive odds.

    Example 2:
    Input: arr = [1,2,34,3,4,5,7,23,12]
    Output: true
    Explanation: [5,7,23] are three consecutive odds.
    """
    # Your code here


# Example Test cases
print(three_consecutive_odd([1, 2, 3, 4, 5]))  # True
print(three_consecutive_odd([2, 6, 4, 1]))  # False
print(three_consecutive_odd([1, 3, 5, 7, 9]))  # True
print(three_consecutive_odd([1, 2, 34, 3, 4, 12, 7, 23, 13]))  # True
