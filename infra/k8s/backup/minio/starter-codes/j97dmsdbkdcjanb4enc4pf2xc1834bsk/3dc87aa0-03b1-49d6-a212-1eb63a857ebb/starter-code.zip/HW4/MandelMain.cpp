#include <iostream>
#include <complex>
#include <algorithm>
#include "cpgplot.h"
#include "Mandel.h"

int main()
{
  float  x=0,y=0;
  float r,g,b;
  const int nPix=255, nCol=64, nMaxIter = 100;
  int nIter;
  int iCol[nPix*nPix];
  int i,j,ci1,ci2;
  float  cReal, cImag;
  float  x0,y0,xrange,yrange;
  char ch;
  
  if (cpgbeg(0,"/xwindow",1,1) != 1) return 1;
  cpgqcol(&ci1,&ci2);
  if (ci2 < 15+nCol) {
    std::cout << "This program requires a device with at least" << 15+nCol << " colors\n";
    return 1;
  }

  cpgpage();
  cpgsvp(0.05,0.95,0.05,0.95);
  cpgwnad(0.0, 1.0, 0.0, 1.0);

  // Set up a color palette using nCol indices from 16 to 15+nCol.
  cpgscr(16, 0.0, 0.0, 0.0);
  for (i=1;i<nCol;i++) {
    r = float(i)/float(nCol-1)*0.8 + 0.2;
    g = std::max(0.0, 2.0*float(i-nCol/2)/float(nCol-1));
    b = float(nCol-1-i)/float(nCol-1);
    cpgscr(i+16, r, g, b);
  }

  // initial view coordinates x is float value, y is imaginary value
  x0 = -0.73;
  y0 = 0.0;
  xrange = 3.0;
  yrange = 3.0;

  // plot loop: keep redrawing the mandelbrot set until user selects exit
  for (;;) {

    // create an array of pixel colours based on the current position (x0,y0)
    // and viewing window size (xrange, yrange)
    for (j=0;j<nPix;j++) {
      cImag = (j-(nPix-1)*.5)*yrange/nPix + y0;
      for (i=0;i<nPix;i++) {
        cReal = (i-(nPix-1)*.5)*xrange/nPix + x0;

        // Find number of interations
        nIter = iCountIterations( std::complex<float>(cReal,cImag), nMaxIter );

        // translate the interations number into a colour index in the range from
        // 16 to 15+nCol for plotting 
	iCol[i+j*nPix] = ((nMaxIter-nIter) % nCol)+16;
     }
    }

    // use pgpixl to plot the pixels
    cpgpixl(iCol, nPix,nPix, 1,nPix, 1,nPix, 0.0, 1.0, 0.0, 1.0);

    // wait for a mouse click or key press from the user
    if (!cpgcurs (&x, &y, &ch)) break;

    // 'a' corresponds to a left click: zoom in
    if (ch == 'a' || ch == 'A') {
      x0 = (x-.5)*xrange+x0;
      y0 = (y-.5)*yrange+y0;
      xrange = xrange*0.8;
      yrange = yrange*0.8;
    }

    // 'x' corresponds to a right click: zoom out
    if (ch == 'x' || ch == 'X' || ch == 'd' || ch == 'D') {
      x0 = (x-.5)*xrange+x0;
      y0 = (y-.5)*yrange+y0;
      xrange = xrange*1.25;
      yrange = yrange*1.25;
    }

    // space or 'q' quits
    if (ch == ' ' || ch == 'q' || ch == 'Q' ) {
      return 0;
    }
  }
}
