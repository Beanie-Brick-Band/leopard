#include <complex>

int iCountIterations(std::complex<float> c, int nMaxIter){
   int iter = 0; 
   std::complex<float> z(0.0,0.0); 
    while (iter < nMaxIter){
        z = (z * z) + c;
        if (std::abs(z) > 2){
            return iter + 1;
        }
        iter++;
    }
    return nMaxIter;

}
