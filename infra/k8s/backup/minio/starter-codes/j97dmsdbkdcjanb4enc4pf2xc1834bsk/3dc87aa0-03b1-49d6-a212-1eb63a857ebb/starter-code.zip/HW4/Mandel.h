int iCountIterations( std::complex<float> c, int nMaxIter );

