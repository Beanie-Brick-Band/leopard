#include <iostream>
#include <complex>
#include "Mandel.h"

using namespace std;

int main() {
    float x, y;
    cout << "Provide a pair of values x and y: ";
    cin >> x;
    cin >> y;

    cout << "x: " << x << ", y: " << y << endl;
    
    std::complex<float> c(x,y);

    int iterations = iCountIterations(c, 100);

    std::cout << "For c = " << c << ":\n";
    std::cout << "Number of iterations: " << iterations << std::endl;
    return 0;
}
