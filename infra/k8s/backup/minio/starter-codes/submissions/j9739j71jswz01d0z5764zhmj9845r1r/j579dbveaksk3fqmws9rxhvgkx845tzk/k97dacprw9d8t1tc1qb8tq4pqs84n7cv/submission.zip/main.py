def fib(n):
    if (n <= 1):
        return 1
    return fib(n-1) + fib(n-2)

#whatever jdalksjdlaskjdlkasjkld

def fib2(n: int) -> int:
    if n < 0:
        raise ValueError("n must be non-negative")
    if n <= 1:
        return n

    a, b = 0, 1
    for _ in range(2, n + 1):
        a, b = b, a + b
    return b


# example
# for i in range(10):
#     print(fib(i))
