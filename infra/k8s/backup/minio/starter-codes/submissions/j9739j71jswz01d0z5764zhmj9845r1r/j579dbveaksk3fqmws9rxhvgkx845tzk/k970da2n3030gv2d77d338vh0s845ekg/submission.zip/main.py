def fibonacci(n):
    if (n <= 0):
        return 0

    cache = [1,1]
    for i in range(1,n):
        a = i % 2
        cache[a] = cache[0] + cache[1]
    
    if (n % 2 == 0):
        return cache[0]
    return cache[1]


print(fibonacci(0))
print(fibonacci(-100))
print(fibonacci(3))
print(fibonacci(4))
print(fibonacci(10))