# Assignment 2
# COMPSCI 1MD3 

def signFunc(nums):
    product = 1
    for n in nums:
        product = product * n
    
    if product == 0:
        return 0
    
    return product / abs(product)

# Test given cases
assert signFunc([-1,-2,-3,-4,3,2,1]) == 1
assert signFunc([1,5,0,2,-3]) == 0
assert signFunc([-1,1,-1,1,-1]) == -1
