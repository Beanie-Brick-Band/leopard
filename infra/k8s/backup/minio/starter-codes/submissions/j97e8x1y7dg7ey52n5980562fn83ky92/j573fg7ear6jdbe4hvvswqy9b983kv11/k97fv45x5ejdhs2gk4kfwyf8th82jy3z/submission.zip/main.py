def signFunc(x):
    if x >= 1:
        return 1
    elif x <= -1:
        return -1
    return 0

def product(nums):
    assert 1 <= len(nums) <= 1000

    x = 1
    for y in nums:
        assert -100 <= y <= 100
        x *= y

    return x



assert signFunc(product([-1,-2,-3,-4,3,2,1])) == 1

assert signFunc(product([1,5,0,2,-3])) == 0

assert signFunc(product([-1,1,-1,1,-1])) == -1
