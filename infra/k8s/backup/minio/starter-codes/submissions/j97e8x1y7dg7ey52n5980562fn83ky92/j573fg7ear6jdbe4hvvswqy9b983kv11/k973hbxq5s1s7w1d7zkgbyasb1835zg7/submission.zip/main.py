from typing import List

def signFunc(x: List[int]) -> int:
    if len(x) < 1:
        raise Exception("List can't be empty")
    product = 1
    for i in x:
        product *= i
    if product > 0:
        return 1
    elif product < 0:
        return -1
    else:
        return 0

print(signFunc([-1,-2,-3,-4,3,2,1]))
print(signFunc([1,5,0,2,-3]))
print(signFunc([-1,1,-1,1,-1]))
print(signFunc([]))

'''
Example 1:

Input: nums = [-1,-2,-3,-4,3,2,1]
Output: 1
Explanation: The product of all values in the array is 144, and signFunc(144) = 1


Example 2:

Input: nums = [1,5,0,2,-3]
Output: 0
Explanation: The product of all values in the array is 0, and signFunc(0) = 0


Example 3:

Input: nums = [-1,1,-1,1,-1]
Output: -1
Explanation: The product of all values in the array is -1, and signFunc(-1) = -1
'''