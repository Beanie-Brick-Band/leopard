def signFunc(x):
    sign = 1
    for n in x:
        if (n == 0):
            return 0
        elif (n < 0):
            sign *= -1
    return sign


print(signFunc([-1,-2,-3,-4,3,2,1])) # 1
print(signFunc([1,5,0,2,-3])) # 0
print(signFunc([-1,1,-1,1,-1])) # -1
