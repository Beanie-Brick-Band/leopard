def main(x):
    if x > 0:
        return 1
    elif x < 0:
        return -1
    return 0