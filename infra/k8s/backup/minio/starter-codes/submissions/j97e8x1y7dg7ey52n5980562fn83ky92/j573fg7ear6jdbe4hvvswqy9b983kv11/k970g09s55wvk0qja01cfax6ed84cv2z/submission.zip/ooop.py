def poop(x):
    return x

print(poop(12))