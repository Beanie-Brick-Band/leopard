def foo (a):
    a = a * 5
    return a

for i in range(5):
    b = foo(6)
    print(b*i)

