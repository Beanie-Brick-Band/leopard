def signFunc(nums):
    prod = 1

    for i in nums:
        prod *= i
    
    if prod == 0:
        return 0
    elif prod > 0:
        return 1
    else:
        return -1

nums = [-1,-2,-3,-4,3,2,1]

print(signFunc(nums))