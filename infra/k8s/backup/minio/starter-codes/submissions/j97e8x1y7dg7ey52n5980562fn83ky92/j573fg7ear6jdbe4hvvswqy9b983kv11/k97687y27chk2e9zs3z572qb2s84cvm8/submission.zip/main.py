def blob():
    print("hello world")