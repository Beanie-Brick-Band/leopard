# function

def signFunc(x):
    product = 1
    for num in x:
        product *= num
    if product > 0:
        # positive
        return 1
    elif product < 0:
        # negative
        return -1
    else:
        # must be 0 case
        return 0


print(signFunc([-1,-2,-3,-4,3,2,1]))
print(signFunc([1,5,0,2,-3]))
print(signFunc([-1,1,-1,1,-1]))