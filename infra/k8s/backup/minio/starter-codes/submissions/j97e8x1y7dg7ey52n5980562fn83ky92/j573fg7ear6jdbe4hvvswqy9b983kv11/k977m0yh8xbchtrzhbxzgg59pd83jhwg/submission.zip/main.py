import math

def signFunc(x):
    return -1 if x < 0 else 1 if x > 0 else 0

def product(nums):
    return math.prod(nums)

print(f"{signFunc(product([-1,-2,-3,-4,3,2,1]))==1=}")
print(f"{signFunc(product([1,5,0,2,-3]))==0=}")
print(f"{signFunc(product([-1,1,-1,1,-1]))==-1=}")