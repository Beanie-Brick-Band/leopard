# Submission for COMPSCI 1MD3
# Assignment 2
# March 24, 2026

def signFunc(L):
    # Calculate product
    total_product = 1
    for number in L:
        total_product *= number

    # Return based on required conditions
    if total_product == 0:
        return 0
    elif total_product < 0:
        return -1
    return 1

print(signFunc([-1,1,-1,1,-1]))