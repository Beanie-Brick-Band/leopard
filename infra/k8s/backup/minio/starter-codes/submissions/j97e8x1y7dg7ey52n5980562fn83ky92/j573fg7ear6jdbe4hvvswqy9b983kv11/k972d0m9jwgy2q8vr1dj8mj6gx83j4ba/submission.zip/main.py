def signFunc(numbers):
    total = 1
    for number in numbers:
        total = total * number

    return total / abs(total) if total else 0 

# Test cases from assignment
assert signFunc([-1,-2,-3,-4,3,2,1]) == 1
assert signFunc([1,5,0,2,-3]) == 0
assert signFunc([-1,1,-1,1,-1]) == -1

