from typing import List

class Solution:
    def arraySign(self, nums: List[int]) -> int:
        negatives = 0
        for x in nums:
            if x == 0:
                return 0
            if x < 0:
                negatives += 1
        return -1 if negatives % 2 else 1


test_cases = [
    # Example cases
    ([-1, -2, -3, -4, 3, 2, 1], 1),
    ([1, 5, 0, 2, -3], 0),
    ([-1, 1, -1, 1, -1], -1),

    # Single element
    ([5], 1),
    ([-5], -1),
    ([0], 0),

    # All positives
    ([1, 2, 3, 4], 1),

    # Even number of negatives
    ([-1, -2], 1),
    ([-1, -2, 3, 4], 1),

    # Odd number of negatives
    ([-1], -1),
    ([-1, 2, 3], -1),
    ([1, -2, 3, -4, -5], -1),

    # Contains zero
    ([0, 1, 2, 3], 0),
    ([1, 2, 3, 0], 0),
    ([-1, -2, 0, 4], 0),

    # Boundary-like values
    ([100, 100, 100], 1),
    ([-100], -1),
    ([-100, -100, 100], 1),
    ([-100, 100, 0], 0),
]

def run_tests():
    sol = Solution()
    for i, (nums, expected) in enumerate(test_cases, 1):
        result = sol.arraySign(nums)
        print(f"Test {i}: {'PASS' if result == expected else 'FAIL'} | nums={nums} | expected={expected}, got={result}")

run_tests()