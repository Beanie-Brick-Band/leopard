for i in range(1,3000):
    print(i)